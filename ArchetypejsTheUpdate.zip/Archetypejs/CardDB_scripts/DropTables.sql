DROP TABLE `yu-gi-oh archetypes`.`archetypes` 
